#!/bin/bash
# Infra Deployment
set -e

echo "Deploying Stack Test-Stack using parameter.json..."

aws cloudformation deploy \
  --template-file ec2-cft.yml \
  --stack-name Test-Stack \
  --parameter-overrides file://parameter.json \
  --capabilities CAPABILITY_NAMED_IAM

echo "Deployment complete!"

#App deployment
chmod 400 LINUX-KEY-PAIR.pem

mkdir -p ~/.ssh

cat <<EOF > ~/.ssh/config
Host *
    StrictHostKeyChecking no
    UserKnownHostsFile=/dev/null
EOF

chmod 600 ~/.ssh/config
echo "Copying software files for deployment"
scp -i LINUX-KEY-PAIR.pem web/* ubuntu@13.127.145.118:/usr/share/nginx/html/
ssh -i LINUX-KEY-PAIR.pem ubuntu@13.127.145.118 'sudo systemctl restart nginx'
scp -i LINUX-KEY-PAIR.pem -r app/* ubuntu@13.201.13.200:/app/
ssh -i LINUX-KEY-PAIR.pem ubuntu@13.201.13.200 '
  cd /app &&
    source venv/bin/activate &&
      nohup venv/bin/uvicorn app:app --host 0.0.0.0 --port 8000 --workers 1 & 
        '